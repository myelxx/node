var express = require('express'),
mongoose = require('mongoose'),
app = express();

mongoose.connect('mongodb+srv://training:training2019@cluster0-hhtdj.mongodb.net/mejidana_db')

require('./routes/user')(app);

app.listen('3000', function(){
	console.log('connected to port 3000');
});

