var User = require('../models/user');

module.exports = (app) => {

	app.set('views', __dirname + '/views');
    app.set('view engine', 'ejs');

	app.get('/', function(req, res){
		//res.render('/', {username: req.params.username});
		res.send("pasok");
	});

	app.get('/:username/:password', function(req, res){
		var username = req.params.username,
			password = req.params.password;

		if(username == null || password == null ){
			res.send("no username or password");
		} 

		if(username.length >= 5 || password.length >= 5){
			res.send("only accept less than 5 username and password");
		} 


		User.findOne({'username':username}, (err, user) => {
	        if(err){
	        	res.send(done(err));	
	            //return done(err);
	        }

	        if(user){
	        	res.send('user already exist');
	            //return done(null, false, req.flash('error', 'user already exist'));
	        }

	        var newUser = new User();
  			newUser.username = req.params.username;
			newUser.password = req.params.username;

			newUser.save((err) => {
			res.send("hello, " + username);	
			return done(null, newUser);
		});
    	})
		
	
		
        
	});
}

 
