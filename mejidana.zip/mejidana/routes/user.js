var User = require('../models/user');

module.exports = (app) => {

	app.set('views', __dirname + '/views');
    app.set('view engine', 'ejs');

	app.get('/', function(req, res){
		//res.render('/', {username: req.params.username});
		res.send("hello");
	});

	app.get('/:username/:password', function(req, res){
		var username = req.params.username;

		// var newUser = new User();
  // 		newewUser.username = req.params.username;
  // 		 newUser.password = req.params.username;

		// newUser.save((err) => {
		// 	return done(null, newUser);
		// });
        
	});
}

 
