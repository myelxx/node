var express = require('express'),
cookieParser = require('cookie-parser'),
bodyParser = require('body-parser'),
ejs = require('ejs'),
mongoose = require('mongoose'),
engine = require('ejs-mate'),
session = require('express-session'),
MongoStore = require('connect-mongo')(session),
passport = require('passport'),
flash = require('connect-flash'),
app = express();

mongoose.connect('mongodb://localhosts/node');

require('./config/passport');

app.use(express.static('public'));
app.engine('ejs', engine);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(cookieParser());
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

app.use(session({
	secret: 'Thisismytestkey',
	resave: false,
	saveUninitialized: false
}));

app.use(flash());

app.use(passport.initialize());
app.use(passport.session());

require('./routes/user')(app);

app.listen('3000', function(){
	console.log('connected to port 3000');
});

app.get('/', function(req, res, next){
	res.render('index');
});

/**

app.get('/second/:test', function(req, res, next){
	res.render('second', {test: req.params.test});
});

app.get('/third/:test', function(req, res, next){
	res.send('third', {test: req.params.test});
});

//mongoose.connect('mongodb://localhost:27017/test', {useNewUrlParser: true});

**/