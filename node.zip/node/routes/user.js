//use EX6 arrow function

module.exports = (app) => {
	app.get('/', function(req, res, next){
		res.render('index', {title: 'Index || Rate Me'});
	});

	app.get('/signup', (req, res) => {
		res.render('user/signup', {title: 'Sign Up || RateMe'});
	});

	app.get('/login', (req, res) => {
		res.render('user/login', {title: 'Login || RateMe'});
	});
}