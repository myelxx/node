var express = require('express'),
mongoose = require('mongoose'),
engine = require('ejs-mate'),
app = express();

app.engine('ejs', engine);

app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/', function(req, res){
	res.render('index');
});

app.get('/second/:test', function(req, res){
	res.render('second', {test: req.params.test});
});

app.get('/third/:test', function(req, res){
	res.send('third', {test: req.params.test});
});

app.listen('3000', function(){
	console.log('connected to port 3000');
});

mongoose.connect('mongodb://localhost:27017/test', {useNewUrlParser: true});
